// ตัวเปลี่ยนรหัสผ่านจริงของระบบอีเมลมหาวิทยาลัย (ตอนนี้เป็น mock)
async function setPassword(email, newPassword) {
  // TODO: เปลี่ยนเป็นการเรียกระบบจริง
  //  - Google Workspace: Admin SDK  users.update({ password })
  //  - Microsoft 365:    Graph API  PATCH /users/{id}  passwordProfile
  //  - LDAP/AD:          ldap modify
  // ห้าม log รหัสผ่านเด็ดขาด
  console.log(`[MOCK] เปลี่ยนรหัสผ่านของ ${email} แล้ว`);
}

module.exports = { setPassword };
