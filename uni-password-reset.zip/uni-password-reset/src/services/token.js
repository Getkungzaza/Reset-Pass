const crypto = require('crypto');

const generateToken = () => crypto.randomBytes(32).toString('hex');
const hashToken = (t) => crypto.createHash('sha256').update(t).digest('hex');

module.exports = { generateToken, hashToken };
