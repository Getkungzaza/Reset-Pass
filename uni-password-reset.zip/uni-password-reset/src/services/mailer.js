const nodemailer = require('nodemailer');

async function sendResetEmail(to, link) {
  // ช่วงพัฒนา: ยังไม่ตั้ง SMTP ให้พิมพ์ลิงก์ใน console แทน
  if (!process.env.SMTP_HOST) {
    console.log(`[DEV] ลิงก์รีเซ็ตสำหรับ ${to}: ${link}`);
    return;
  }
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  await transporter.sendMail({
    from: process.env.MAIL_FROM,
    to,
    subject: 'ลิงก์รีเซ็ตรหัสผ่านอีเมลมหาวิทยาลัย',
    text: `กดลิงก์เพื่อตั้งรหัสผ่านใหม่ (หมดอายุใน 15 นาที):\n${link}\n\nถ้าคุณไม่ได้ขอ ให้ละเว้นอีเมลนี้`,
  });
}

module.exports = { sendResetEmail };
