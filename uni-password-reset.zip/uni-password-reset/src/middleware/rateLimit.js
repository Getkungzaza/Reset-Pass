const rateLimit = require('express-rate-limit');

const requestLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 ชั่วโมง
  max: 5,                   // 5 ครั้งต่อ IP
  message: { message: 'ส่งคำขอบ่อยเกินไป กรุณาลองใหม่ภายหลัง' },
});

module.exports = { requestLimiter };
