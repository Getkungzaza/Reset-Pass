const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '..', 'data.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    student_id   TEXT PRIMARY KEY,
    email        TEXT UNIQUE,
    backup_email TEXT,
    birth_date   TEXT
  );
  CREATE TABLE IF NOT EXISTS reset_tokens (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id   TEXT NOT NULL,
    token_hash   TEXT NOT NULL,
    expires_at   INTEGER NOT NULL,
    used_at      INTEGER,
    requested_ip TEXT
  );
`);

// ข้อมูลทดสอบ (ของจริงให้ดึงจากฐานข้อมูลนักศึกษาของมหาวิทยาลัย)
db.prepare('INSERT OR IGNORE INTO users VALUES (?,?,?,?)')
  .run('6400000001', 'test@uni.ac.th', 'backup@example.com', '2002-01-31');

module.exports = db;
