require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
// ถ้าวางหลัง reverse proxy (Nginx) ให้เปิดบรรทัดนี้ เพื่อให้ req.ip ถูกต้อง
// app.set('trust proxy', 1);

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/api/reset', require('./routes/reset'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`รันที่ http://localhost:${PORT}/forgot.html`));
