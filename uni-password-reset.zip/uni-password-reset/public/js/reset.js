const token = new URLSearchParams(location.search).get('token');
const msg = document.getElementById('msg');

document.getElementById('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const { pw1, pw2 } = Object.fromEntries(new FormData(e.target));
  if (pw1 !== pw2) return (msg.textContent = 'รหัสผ่านไม่ตรงกัน');

  const res = await fetch('/api/reset/confirm', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token, new_password: pw1 }),
  });
  msg.textContent = (await res.json()).message;
});
